Файлы автоматической сборки находятся в `workflows/`:
- `build-server.yml` — Paper-плагин.
- `build-client.yml` — Fabric-клиентский мод.

Инструкция на русском: `../GITHUB_ACTIONS_RU.md`.
